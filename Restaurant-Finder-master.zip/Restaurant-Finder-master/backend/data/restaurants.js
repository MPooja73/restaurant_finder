const restaurants = [
  { name: "6 BALLYGUNGE PLACE", location: "KOLKATA", price: 250},
  { name: "AISH", location: "HYDERABAD", price: 2500},
  { name: "AGASHIYE", location: "AHMEDABAD", price: 500},
  { name: "AMBRAI", location: "UDAIPUR", price: 900 },
];

export default restaurants;