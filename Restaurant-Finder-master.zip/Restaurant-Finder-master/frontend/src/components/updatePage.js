import React from "react";
import UpdateRestaurant from "./UpdateRestaurant";

const updatePage = () => {
  return (
    <>
      <h1 className="text-center">Update Restaurant</h1>
      <UpdateRestaurant />
    </>
  );
};

export default updatePage;
