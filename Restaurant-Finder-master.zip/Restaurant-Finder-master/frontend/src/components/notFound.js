import React from "react";

const notFound = () => {
  return <div>Not Found</div>;
};

export default notFound;
